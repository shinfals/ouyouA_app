#include <stdio.h>
#include "func.h"
//グローバル変数などあれば
void main (){
	system("chcp 65001");
	gameMain();
}