#include <stdio.h>
#include <stdlib.h>
#include "func.h"
void gameEnd(){
	printf("Game Over\n");
	//exit(0);
	//system("pause");
}