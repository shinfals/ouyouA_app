#include <stdio.h>
#include "func.h"
int end_initialize(){
  int end_flag = 0;
  return end_flag;
}