#pragma once
//define�@�錾�͂����ɂ܂Ƃ߂܂�
#define NUM_OF_ROOM 25//main
#define NUM_OF_ENEMY 9//main
#define MAP_WIDTH 5//game_start
#define MAP_HEIGHT 5//game_start
#define ROOM_WIDTH 16//game_start
#define ROOM_HEIGHT 7//game_start